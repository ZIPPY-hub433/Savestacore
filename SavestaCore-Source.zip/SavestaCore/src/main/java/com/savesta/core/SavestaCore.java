package com.savesta.core;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public final class SavestaCore extends JavaPlugin implements Listener, CommandExecutor {
    private static final String TITLE = "§8Savesta §7» §6Settings";
    private NamespacedKey commandKey;
    private final Map<String, MenuItem> items = new LinkedHashMap<>();

    @Override
    public void onEnable() {
        commandKey = new NamespacedKey(this, "menu_command");
        items.put("shop", new MenuItem(Material.EMERALD, "§aShop", "/shop"));
        items.put("ah", new MenuItem(Material.CHEST, "§6Auction House", "/ah"));
        items.put("order", new MenuItem(Material.WRITABLE_BOOK, "§eOrders", "/order"));
        items.put("home", new MenuItem(Material.RED_BED, "§bHomes", "/home"));
        items.put("rtp", new MenuItem(Material.COMPASS, "§dRandom Teleport", "/rtp"));
        items.put("spawn", new MenuItem(Material.NETHER_STAR, "§cSpawn", "/spawn"));
        items.put("leaderboard", new MenuItem(Material.GOLD_INGOT, "§6Leaderboard", "/leaderboard"));
        items.put("status", new MenuItem(Material.BOOK, "§fStatus", "/status"));

        Objects.requireNonNull(getCommand("settings")).setExecutor(this);
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("SavestaCore enabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command can only be used in-game.");
            return true;
        }
        if (!player.hasPermission("savestacore.settings")) {
            player.sendMessage("§cYou don't have permission.");
            return true;
        }

        Inventory gui = Bukkit.createInventory(null, 27, TITLE);
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 22};
        int i = 0;
        for (MenuItem item : items.values()) {
            ItemStack stack = new ItemStack(item.material());
            ItemMeta meta = stack.getItemMeta();
            meta.setDisplayName(item.name());
            meta.setLore(List.of("§7Click to run §f" + item.command()));
            meta.getPersistentDataContainer().set(commandKey, PersistentDataType.STRING, item.command());
            stack.setItemMeta(meta);
            gui.setItem(slots[i++], stack);
        }

        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        fillerMeta.setDisplayName(" ");
        filler.setItemMeta(fillerMeta);
        for (int slot = 0; slot < gui.getSize(); slot++) {
            if (gui.getItem(slot) == null) gui.setItem(slot, filler);
        }

        player.openInventory(gui);
        return true;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!TITLE.equals(event.getView().getTitle())) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null ||
                event.getClickedInventory() != event.getView().getTopInventory()) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;
        String command = clicked.getItemMeta().getPersistentDataContainer()
                .get(commandKey, PersistentDataType.STRING);
        if (command == null) return;

        player.closeInventory();
        player.performCommand(command.substring(1));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (TITLE.equals(event.getView().getTitle())) event.setCancelled(true);
    }

    private record MenuItem(Material material, String name, String command) {}
}
