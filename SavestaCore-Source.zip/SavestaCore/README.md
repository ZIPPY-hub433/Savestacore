# SavestaCore

Paper plugin for Savesta SMP. `/settings` opens a 27-slot GUI with buttons for `/shop`, `/ah`, `/order`, `/home`, `/rtp`, `/spawn`, `/leaderboard`, and `/status`.

**This plugin is a menu only.** It runs each command as the player. Other plugins or your server setup must provide those commands. It does not implement the economy, auction house, homes, RTP, leaderboard, or status features itself.

## Build and install

1. Use the Java version required by your Paper 26.2 server (configured here as Java 25).
2. Run `gradle build` from this project folder.
3. Copy `build/libs/SavestaCore-1.0.0.jar` into the server's `plugins` folder.
4. Restart the server and use `/settings`.

The Paper API dependency is set to `26.2-R0.1-SNAPSHOT`. If Paper publishes a different exact 26.2 API version, update that version in `build.gradle` to match the official repository.
