SAVESTACORE 1.0.0
==================

One Paper plugin that provides a /settings menu for Savesta SMP.

Menu buttons:
- Shop -> runs /shop
- Auction House -> runs /ah
- Orders -> runs /order
- Homes -> runs /home
- Random Teleport -> runs /rtp
- Spawn -> runs /spawn
- Settings -> placeholder message for future settings

IMPORTANT:
This plugin creates the menu and runs the listed commands as the player.
It does NOT implement the shop, auction house, orders, homes, RTP, or spawn
systems itself. Those commands must be provided by other plugins or by your
server setup. Change the command strings in config.yml if your server uses
different command names.

ESC MENU LIMITATION:
A server-side Paper plugin cannot replace or add a button to the client's
ESC/pause screen. Players open this menu with /settings. Adding it to the
actual pause screen requires a separate client-side mod.

TARGET:
- Minecraft Java 26.2
- Paper 26.2
- Java 25

BUILD:
1. Use a computer or build environment with JDK 25 and Gradle 8.14+ (or a
   compatible newer Gradle version).
2. Open this project folder.
3. Run: gradle build
4. The plugin JAR will be in build/libs/SavestaCore-1.0.0.jar

INSTALL:
1. Stop the Paper server and back up the server.
2. Upload SavestaCore-1.0.0.jar to the server's plugins folder.
3. Start the server.
4. Join and run /settings.

This ZIP is the source project, not a compiled JAR. This environment does not
have JDK 25 / Gradle installed, so the JAR could not be compiled here.
