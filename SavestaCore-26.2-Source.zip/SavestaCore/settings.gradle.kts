rootProject.name = "SavestaCore"
